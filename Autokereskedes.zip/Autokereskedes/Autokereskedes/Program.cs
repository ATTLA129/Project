﻿namespace Autokereskedes
    {
        internal class Program
        {
            class Auto
            {
                public string Rendszam;
                public string Marka;
                public string Modell;
                public int GyartasiEv;
                public int KmAllas;
                public int Ar;
                public string Uzemanyag;

                public Auto(string sor)
                {
                    string[] adatok = sor.Split(';');
                    this.Rendszam = adatok[0];
                    this.Marka = adatok[1];
                    this.Modell = adatok[2];
                    this.GyartasiEv = Convert.ToInt32(adatok[3]);
                    this.KmAllas = Convert.ToInt32(adatok[4]);
                    this.Ar = Convert.ToInt32(adatok[5]);
                    this.Uzemanyag = adatok[6];
                }
            }

            static void Main(string[] args)
            {
                List<Auto> autok = new List<Auto>();

                string[] sorok = File.ReadAllLines("adatok.txt");

                for (int i = 1; i < sorok.Length; i++)
                {
                    if (sorok[i] != "")
                    {
                        Auto ujAuto = new Auto(sorok[i]);
                        autok.Add(ujAuto);
                    }
                }

                Console.WriteLine($"Beolvasott autók száma: {autok.Count} db\n");

                double osszKm = 0;
                foreach (Auto a in autok)
                {
                    osszKm += a.KmAllas;
                }
                double atlagKm = osszKm / autok.Count;
                Console.WriteLine($"1. Átlagos kilométeróra-állás: {Math.Round(atlagKm)} km");

                int maxIndex = 0;
                for (int i = 1; i < autok.Count; i++)
                {
                    if (autok[i].Ar > autok[maxIndex].Ar)
                    {
                        maxIndex = i;
                    }
                }
                Console.WriteLine($"2. A legdrágább autó: {autok[maxIndex].Marka} {autok[maxIndex].Modell} - {autok[maxIndex].Ar} Ft");

                int benzinDb = 0;
                foreach (Auto a in autok)
                {
                    if (a.Uzemanyag == "Benzin")
                    {
                        benzinDb++;
                    }
                }
                Console.WriteLine($"3. Benzinmotoros autók száma: {benzinDb} db");

                Console.Write("\n4. Adj meg egy autómárkát (pl. Toyota): ");
                string keresettMarka = Console.ReadLine();
                bool vanTalalat = false;

                Console.WriteLine($"\nTalálatok a(z) '{keresettMarka}' márkára:");
                foreach (Auto a in autok)
                {
                    if (a.Marka.ToLower() == keresettMarka.ToLower())
                    {
                        Console.WriteLine($" - {a.Rendszam}: {a.Modell} ({a.GyartasiEv}), Ár: {a.Ar} Ft");
                        vanTalalat = true;
                    }
                }

                if (!vanTalalat)
                {
                    Console.WriteLine("Sajnos nincs ilyen márkájú autó a listában.");
                }

                Console.WriteLine("\nNyomj Entert a kilépéshez...");
                Console.ReadLine();
            }
        }
    }